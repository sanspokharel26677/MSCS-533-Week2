import { Text, View, StyleSheet, Image } from 'react-native';

// The code below will display my BioSketch @ UC, and it's amazing!!!!!
export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={require('../assets/sandesh_image.JPG')} />
      <Text style={styles.paragraph}>
        Sandesh Pokharel is a student at UC where he is pursuing Masters of Computer Science Degree.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: 'white', // Adding background color to match the card style
    borderRadius: 10, // Slight rounding for a card-like appearance
  },
  paragraph: {
    margin: 24,
    marginTop: 10,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'black',
  },
  logo: {
    height: 128,
    width: 128,
    borderRadius: 64, // Circular image styling
  }
});
